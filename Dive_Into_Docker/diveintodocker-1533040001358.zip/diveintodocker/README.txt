Hi, thanks for signing up!

  I just wanted to let you know that you can access the notes by going to the
  `notes` folder and then opening up the index.html file in a web browser.



Having trouble accessing the notes on iOS?

  Try the Documents 5 application, it's free:
  https://itunes.apple.com/us/app/documents-5-file-manager-pdf-reader-and-browser/id364901807?mt=8

  Feel free to use any other document viewing app if you happen to have one already.



Having issues?

  Check out the `support` link in the notes, or email me at nick@diveintodocker.com.



Thanks again!
 
  Nick Janetakis (author of Dive Into Docker)

    https://diveintodocker.com
    https://nickjanetakis.com
