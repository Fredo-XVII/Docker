# Django

This is a pretty bare bones Django application that creates a "hello" app.

It also happens to use `gunicorn`, so you're set for both development and production.

View all of [gunicorn's documentation](http://docs.gunicorn.org/en/latest/index.html).
