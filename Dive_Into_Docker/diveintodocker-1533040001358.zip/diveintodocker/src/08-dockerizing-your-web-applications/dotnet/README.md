# .NET

A very simple console based "Hello World!" application.

## Would you like something better?

I know I would, but I'm not a .NET developer. I feel like at this point, it
would be better to get assistance from a real .NET developer. Perhaps together
we can make a better web based hello world example that supports automated
code reloads in development, etc..

If you want to pair up on this, e-mail at me at nick@diveintodocker.com.
